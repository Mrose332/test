const Comedian = require('./Comedian');
const Show = require('./Show');


module.exports = { Comedian, Show };
